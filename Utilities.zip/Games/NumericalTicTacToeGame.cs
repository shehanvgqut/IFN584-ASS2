﻿using IFN584_ASS2.Core;
using IFN584_ASS2.UserUI;
using IFN584_ASS2.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;

namespace IFN584_ASS2.Games
{
    public class NumericalTicTacToeGame : GameTemplate
    {
        private int[,] board;
        private HashSet<int> usedNumbers = new();
        private int boardSize;
        private int targetSum;

        protected override void Initialize()
        {
            Console.Write("Enter board size (e.g. 3 for 3x3): ");
            while (!int.TryParse(Console.ReadLine(), out boardSize) || boardSize < 2)
            {
                ConsoleRenderer.ShowError("Please enter a valid integer (minimum 2).");
            }

            board = new int[boardSize, boardSize];
            targetSum = boardSize * (boardSize * boardSize + 1) / 2;

            ConsoleRenderer.RenderMessage($"🎯 Starting Numerical Tic-Tac-Toe {boardSize}x{boardSize}. Target sum: {targetSum}");
        }

        protected override void DisplayBoard()
        {
            ConsoleRenderer.RenderBoard(board);
        }

        protected override void MakeMove(int input)
        {
            // This is not used anymore, logic moved to MakeMoveWithCoords.
            ConsoleRenderer.ShowError("Direct input not supported. Use row/col format.");
        }

        protected override void MakeMoveWithCoords(int input, int row, int col)
        {
            int maxVal = boardSize * boardSize;

            if (input < 1 || input > maxVal)
            {
                ConsoleRenderer.ShowError($"🚫 Input must be between 1 and {maxVal}.");
                return;
            }

            if (usedNumbers.Contains(input))
            {
                ConsoleRenderer.ShowError("🚫 This number has already been used.");
                return;
            }

            if ((CurrentPlayer.IsOddPlayer && input % 2 == 0) ||
                (!CurrentPlayer.IsOddPlayer && input % 2 != 0))
            {
                ConsoleRenderer.ShowError("🚫 You must use your assigned number type (odd/even).");
                return;
            }

            if (row < 0 || row >= boardSize || col < 0 || col >= boardSize)
            {
                ConsoleRenderer.ShowError("🚫 Row or column is out of bounds.");
                return;
            }

            if (board[row, col] != 0)
            {
                ConsoleRenderer.ShowError("🚫 That spot is already taken.");
                return;
            }

            board[row, col] = input;
            usedNumbers.Add(input);
            GameState.RecordMove(new Move(row, col, input));
        }

        protected override bool IsGameOver()
        {
            for (int i = 0; i < boardSize; i++)
            {
                if (IsLineWinning(i, true) || IsLineWinning(i, false))
                    return true;
            }

            if (IsDiagonalWinning(true) || IsDiagonalWinning(false))
                return true;

            return usedNumbers.Count == boardSize * boardSize;
        }

        private bool IsLineWinning(int index, bool isRow)
        {
            int sum = 0;
            for (int j = 0; j < boardSize; j++)
            {
                int val = isRow ? board[index, j] : board[j, index];
                if (val == 0) return false;
                sum += val;
            }
            return sum == targetSum;
        }

        private bool IsDiagonalWinning(bool main)
        {
            int sum = 0;
            for (int i = 0; i < boardSize; i++)
            {
                int val = main ? board[i, i] : board[i, boardSize - 1 - i];
                if (val == 0) return false;
                sum += val;
            }
            return sum == targetSum;
        }

        protected override void AnnounceResult()
        {
            if (usedNumbers.Count == boardSize * boardSize)
                ConsoleRenderer.RenderMessage("🤝 It's a draw!");
            else
                ConsoleRenderer.RenderMessage($"🏆 {CurrentPlayer.Name} wins!");
        }

        protected override void SaveGame()
        {
            FileManager.Save(this);
        }

        protected override void ShowHelp()
        {
            HelpProvider.ShowHelp("numerical");
        }
        public override void Play()
        {
            Initialize();

            while (!IsGameOver())
            {
                DisplayBoard();

                bool validInput = false;
                while (!validInput)
                {
                    ConsoleRenderer.PromptPlayer(CurrentPlayer.Name);
                    string? input = Console.ReadLine()?.Trim().ToLower();

                    if (input == "help") { ShowHelp(); continue; }
                    if (input == "undo") { Undo(); validInput = true; continue; }
                    if (input == "redo") { Redo(); validInput = true; continue; }
                    if (input == "save") { SaveGame(); validInput = true; continue; }

                    if (int.TryParse(input, out int num))
                    {
                        if (!IsMoveNumberValid(num))
                        {
                            ConsoleRenderer.ShowError("🚫 That number is invalid or already used.");
                            continue;
                        }

                        Console.Write($"Enter row (1–{MaxRow + 1}): ");
                        if (!int.TryParse(Console.ReadLine(), out int row) || row < 1 || row > MaxRow + 1)
                        {
                            ConsoleRenderer.ShowError($"🚫 Invalid row. Please enter 1 to {MaxRow + 1}.");
                            continue;
                        }

                        Console.Write($"Enter col (1–{MaxCol + 1}): ");
                        if (!int.TryParse(Console.ReadLine(), out int col) || col < 1 || col > MaxCol + 1)
                        {
                            ConsoleRenderer.ShowError($"🚫 Invalid column. Please enter 1 to {MaxCol + 1}.");
                            continue;
                        }

                        MakeMoveWithCoords(num, row - 1, col - 1); // Convert to 0-based
                        validInput = true;
                    }
                    else
                    {
                        ConsoleRenderer.ShowError("🚫 Invalid command or input.");
                    }
                }

                if (!IsGameOver())
                    SwitchPlayers();
            }

            DisplayBoard();
            AnnounceResult();
        }
        protected override bool IsComputerTurn()
        {
            return CurrentPlayer.Name == "Computer";
        }

        protected override void MakeComputerMove()
        {
            List<int> availableNumbers = CurrentPlayer.IsOddPlayer
                ? Enumerable.Range(1, boardSize * boardSize).Where(n => n % 2 != 0 && !usedNumbers.Contains(n)).ToList()
                : Enumerable.Range(1, boardSize * boardSize).Where(n => n % 2 == 0 && !usedNumbers.Contains(n)).ToList();

            Random rand = new Random();

            // Try to find a winning move
            foreach (int num in availableNumbers)
            {
                for (int r = 0; r < boardSize; r++)
                {
                    for (int c = 0; c < boardSize; c++)
                    {
                        if (board[r, c] == 0)
                        {
                            board[r, c] = num;
                            bool wins = IsGameOver();
                            board[r, c] = 0;

                            if (wins)
                            {
                                MakeMoveWithCoords(num, r, c);
                                return;
                            }
                        }
                    }
                }
            }

            // If no winning move, choose random valid move
            while (true)
            {
                int row = rand.Next(boardSize);
                int col = rand.Next(boardSize);

                if (board[row, col] == 0)
                {
                    int value = availableNumbers[rand.Next(availableNumbers.Count)];
                    MakeMoveWithCoords(value, row, col);
                    return;
                }
            }
        }


        // Let GameTemplate know the board size dynamically
        protected override int MaxRow => boardSize - 1;
        protected override int MaxCol => boardSize - 1;
    }
}
