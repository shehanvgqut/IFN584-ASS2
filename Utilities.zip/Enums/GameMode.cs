﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IFN584_ASS2.Enums
{
    public enum GameMode
    {
        HumanVsHuman,
        HumanVsComputer
    }
}
